# 跨科橋樑：如何沿用並整合到 `auto-control-wiki`

- **對應原始資料**：`raw/01_ncku_ee_exam_scope.md`、`raw/03_laplace_and_convolution.md`、`raw/05_linear_algebra_eigen_svd.md`
- **外部來源**：[成大圖書館電機系碩士班考古題 EC15](https://exam.lib.ncku.edu.tw/master_subject.php?department_code=EC15)、[MIT OCW 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/least-squares-determinants-and-eigenvalues/diagonalization-and-powers-of-a/)
- **相關條目**：[[overview]]、[[laplace]]、[[linear-algebra]]、[[fourier]]

## 一句話白話理解
工程數學是「底層引擎」，自動控制與電路學是「開在上面的車」；把兩個 LLM Wiki 接起來，就能看到同一個數學觀念在不同考科的真面目。

## 生活／工程直覺
唸自動控制時背的「左半平面極點才會穩定」，其實就是工數裡 ODE 特徵根實部小於零、以及線性代數裡狀態矩陣 $A$ 的特徵值實部小於零——三件事講的是完全同一件事。

## 工數 × 自動控制概念對照表
| 工程數學 Wiki 條目 | 自動控制 (`auto-control-wiki`) 對應概念 | 考題串聯重點 |
| :--- | :--- | :--- |
| [[ode]] 二階齊性解特徵根 | 二階系統阻尼比 $\zeta$ 與自然頻率 $\omega_n$ | 過阻尼／臨界阻尼／欠阻尼步階響應 |
| [[laplace]] 拉普拉斯轉換 | 轉移函數 $G(s) = Y(s)/U(s)$ | 初始條件為零時的輸入輸出關係 |
| [[fourier]] 傅立葉頻域響應 | 波德圖（Bode Plot）與頻寬 | 令 $s = j\omega$ 觀察增益與相位餘度 |
| [[linear-algebra]] 特徵值與 $e^{At}$ | 狀態空間穩定度與狀態轉移矩陣 $\Phi(t)$ | $\det(sI - A) = 0$ 的根即系統極點 |
| [[complex-analysis]] 封閉路徑與奇點 | 奈奎斯特準則（Nyquist Stability Criterion） | 輻角原理計算包圍 $(-1, 0)$ 的圈數 |

## 如何實作沿用（兩步驟合併法）
1. 將本專案的 `raw/01~06*.md` 與 `wiki/*.md` 直接複製進既有的 `auto-control-wiki` 對應資料夾。
2. 在原專案的 `wiki/index.md` 補上「工程數學模組」連結並指向 `wiki/control-bridge.md`，即可在不破壞舊筆記的前提下完成雙科知識圖譜。
