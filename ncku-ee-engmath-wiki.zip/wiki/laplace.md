# 拉普拉斯轉換與摺積：把微積分變四則運算

- **對應原始資料**：`raw/03_laplace_and_convolution.md`
- **外部來源**：[Paul's Online Notes — Solving IVPs](https://tutorial.math.lamar.edu/classes/de/ivpwithlaplace.aspx)、[Convolution Integrals](https://tutorial.math.lamar.edu/classes/de/convolutionintegrals.aspx)、[Laplace Table](https://tutorial.math.lamar.edu/classes/de/laplace_table.aspx)
- **相關條目**：[[ode]]、[[fourier]]、[[control-bridge]]

## 一句話白話理解
拉普拉斯轉換就像「時域到 $s$ 域的翻譯機」：原本很難算的微分與積分，翻過去之後全變成乘以 $s$ 與除以 $s$ 的國中代數。

## 生活／工程直覺
直接解微分方程像用羅馬數字做乘法；先取 Laplace 轉換就像換成阿拉伯數字算完再換回來。更棒的是，初始條件 $y(0), y'(0)$ 在轉換第一步就自動包進去，而且碰到開關突然切換（步階函數）或瞬間脈衝（Delta 函數）也能輕鬆處理。

## 標準三步流程與摺積武器
1. **轉到 $s$ 域**：利用 $\mathcal{L}\{y'\} = sY(s) - y(0)$ 與 $\mathcal{L}\{y''\} = s^2Y(s) - sy(0) - y'(0)$。
2. **代數整理**：移項求出 $Y(s)$，用部分分式展開拆成基本項。
3. **逆轉換回時域**：查表取 $\mathcal{L}^{-1}\{Y(s)\}$；若 $Y(s) = F(s)G(s)$ 不好拆，改用**摺積定理**：
   $$\mathcal{L}^{-1}\{F(s)G(s)\} = (f * g)(t) = \int_0^t f(t - \tau)g(\tau)\,d\tau$$

## 考場易錯提醒
- 忘記減去初始條件項 $-sy(0) - y'(0)$。
- 摺積積分上下限是 $0$ 到 $t$，且兩個函數可以互換以簡化積分計算。
