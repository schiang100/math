# 常微分方程 ODE：描述動態變化的語言

- **對應原始資料**：`raw/02_ode_first_second_order.md`
- **外部來源**：[Paul's Online Notes — Differential Equations](https://tutorial.math.lamar.edu/classes/de/de.aspx)、[MIT OCW ES.1803](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/pages/class-notes/)
- **相關條目**：[[overview]]、[[laplace]]、[[linear-algebra]]

## 一句話白話理解
微分方程就是「用現在的狀態，去描述下一秒變化得有多快」，解出它就能預測系統未來每一秒的走勢。

## 生活／工程直覺
電容充電時，電壓越高、充電電流越小（一階 ODE）；車子壓過減速丘時，彈簧想彈回去、避震器想讓它停下來（二階 ODE）。這兩件事寫成數學，就是電機考場最常出現的一階與二階常微分方程。

## 新手必懂的三步解題框架
1. **看階數與線性度**：一階先判斷是否可分離變數、是否可用積分因子或正合方程。
2. **求齊性解 $y_h$（系統天性）**：解特徵方程式 $ar^2 + br + c = 0$。
   - 兩相異實根 → 指數平滑衰減（過阻尼）
   - 重根 → 多乘一個 $t$ 維持獨立（臨界阻尼）
   - 共軛複根 → 衰減振盪波形（欠阻尼）
3. **求特解 $y_p$（外力強迫）並相加**：總響應 $y(t) = y_h(t) + y_p(t)$，最後代入初始條件定出常數。

## 考場易錯提醒
- 重根時忘記補乘 $t$（可用 Wronskian 檢查線性獨立）。
- 待定係數法的猜測項若與齊性解 $y_h$ 重複，必須乘上 $t$ 修正。
