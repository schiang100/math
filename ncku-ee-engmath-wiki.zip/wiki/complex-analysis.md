# 複變函數與留數定理：繞道複數平面解積分

- **對應原始資料**：`raw/06_complex_residue_theorem.md`
- **外部來源**：[MIT OCW 18.04 — Cauchy's Integral Formula](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/b1a90df19f643b974555bbbb93138a48_MIT18_04S18_topic4.pdf)、[Residue Theorem](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/3c58ce71ec6f7573804221d76158a0bd_MIT18_04S18_topic8.pdf)
- **相關條目**：[[laplace]]、[[fourier]]、[[overview]]

## 一句話白話理解
實數軸上卡死的困難積分，把它放進複數平面畫一個封閉圈圈，只要檢查圈圈裡包了哪幾個「奇點（地雷）」，把每個奇點的留數加起來乘上 $2\pi i$ 就是答案。

## 生活／工程直覺
把複數平面想像成一片草地，封閉路徑 $C$ 是一條圍欄。如果圍欄裡一片平坦（函數處處解析），繞一圈回來積分永遠是 0；唯一會讓積分不為 0 的，就是圍欄裡包到的「奇點」，而留數（Residue）就是每個奇點貢獻的權重。

## 留數定理實戰三步驟
1. **找出所有奇點並判斷階數**：解分母為 0 的點 $z_k$，確認哪些落在封閉路徑 $C$ **內部**（外部的不算！）。
2. **計算圈內各奇點的留數**：
   - 一階極點（Simple Pole）：$\operatorname{Res}(f, z_0) = \lim_{z \to z_0} (z - z_0) f(z)$
   - $m$ 階極點：$\operatorname{Res}(f, z_0) = \frac{1}{(m-1)!} \lim_{z \to z_0} \frac{d^{m-1}}{dz^{m-1}}[(z - z_0)^m f(z)]$
3. **套用留數定理**：$\oint_C f(z)\,dz = 2\pi i \sum \operatorname{Res}(f, z_j)$。

## 考場易錯提醒
- 忘記檢查奇點是否真的在「上半平面」或指定路徑內部，把路徑外的極點也加進去是最大失分點。
