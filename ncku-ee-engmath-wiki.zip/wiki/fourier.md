# 傅立葉分析：把訊號拆成頻率配方

- **對應原始資料**：`raw/04_fourier_series_and_transform.md`
- **外部來源**：[MIT OCW 18.03SC — Fourier Series: Basics](https://ocw.mit.edu/courses/18-03sc-differential-equations-fall-2011/pages/unit-iii-fourier-series-and-laplace-transform/fourier-series-basics/)、[ES.1803 Topic 21](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/mites_1803_s24_topic21.pdf)
- **相關條目**：[[laplace]]、[[complex-analysis]]、[[overview]]

## 一句話白話理解
傅立葉分析就像幫聲音或電流做「成分標示」：把任何複雜的波形，拆解成不同頻率的正弦波各自佔多少比例。

## 生活／工程直覺
你聽一首歌時，喇叭輸出的是一條彎彎曲曲的總電壓波形；但音樂播放器的等化器（EQ）可以單獨把低音調強、高音濾掉——這背後就是把時域波形透過傅立葉分析轉到頻域，看清每個頻率的強度。

## 核心公式與考場捷徑
- **週期訊號 → 傅立葉級數**：
  $$f(t) = \frac{a_0}{2} + \sum_{n=1}^{\infty} \left(a_n \cos(n\omega_0 t) + b_n \sin(n\omega_0 t)\right)$$
- **非週期訊號 → 傅立葉轉換**：週期 $T \to \infty$ 時，離散諧波變為連續頻譜 $F(\omega)$。
- **奇偶對稱省時術**：
  - 偶函數（左右對稱）→ $b_n = 0$，只算 $a_n$。
  - 奇函數（原點對稱）→ $a_0 = a_n = 0$，只算 $b_n$。

## 考場易錯提醒
- 直流項係數常寫作 $a_0/2$，套公式時要注意是否已除以 2。
- 在不連續點（如方波跳變處），傅立葉級數會收斂到左右極限的平均值，且邊緣會出現吉布斯現象（Gibbs Phenomenon）。
