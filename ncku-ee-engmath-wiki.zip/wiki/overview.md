# 成大電機工程數學全域地圖（Overview）

- **對應原始資料**：`raw/01_ncku_ee_exam_scope.md`
- **外部來源**：[成大圖書館電機系碩士班考古題 EC15](https://exam.lib.ncku.edu.tw/master_subject.php?department_code=EC15)、[ColleGo! 電機工程學類](https://collego.edu.tw/Highschool/MajorIntro?current_major_id=9&collegeFrom=2)
- **相關條目**：[[ode]]、[[laplace]]、[[fourier]]、[[linear-algebra]]、[[complex-analysis]]、[[control-bridge]]

## 一句話白話理解
工程數學不是在考背公式，而是一套「把真實電路、訊號與控制系統翻譯成數學，再挑最省力工具解出來」的工具箱。

## 生活／工程直覺
想像你要設計一架無人機或一組濾波電路：物理定律寫出來一定是一堆微分方程（變化率）。工程數學的五大單元就像五把不同的扳手——有些問題直接算最慢，但換個視角（轉到頻率域、轉到矩陣特徵空間、或繞道複數平面）就會瞬間變簡單。

## 成大電機碩士班五大核心單元
1. **常微分方程（[[ode]]）**：建立系統的「時域動態模型」。
2. **拉普拉斯轉換（[[laplace]]）**：處理帶初始條件的暫態問題，直接銜接控制系統與電路學。
3. **傅立葉分析（[[fourier]]）**：把複雜訊號拆成不同頻率的正弦波，看懂濾波與通訊。
4. **線性代數（[[linear-algebra]]）**：處理多變數耦合系統（狀態空間、特徵值、SVD）。
5. **複變函數（[[complex-analysis]]）**：用留數定理秒殺實數軸上的困難積分與逆轉換。
