# 線性代數：特徵值、對角化與 SVD

- **對應原始資料**：`raw/05_linear_algebra_eigen_svd.md`
- **外部來源**：[MIT OCW 18.06SC — Diagonalization](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/least-squares-determinants-and-eigenvalues/diagonalization-and-powers-of-a/)、[SVD](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/positive-definite-matrices-and-applications/singular-value-decomposition/)、[MIT 18.06 PSet 9](https://web.mit.edu/18.06/www/Spring09/pset9-s09-soln.pdf)
- **相關條目**：[[ode]]、[[control-bridge]]、[[overview]]

## 一句話白話理解
矩陣代表一種空間變換，而特徵向量就是「變換後方向完全不偏、只會拉長或縮短」的關鍵主軸。

## 生活／工程直覺
如果一個系統有三個互相牽連的變數（例如多關節機械臂或複雜電路），直接算會綁手綁腳。透過「對角化」換到特徵向量的座標系，原本糾纏在一起的方程就會拆成三個彼此獨立的一維問題，算完再換回來就好。

## 三大必考核心
1. **特徵值分解與對角化**：由 $\det(A - \lambda I) = 0$ 求特徵值；若有 $n$ 個獨立特徵向量，則 $A = S\Lambda S^{-1}$，讓 $A^k = S\Lambda^k S^{-1}$ 與 $e^{At} = S e^{\Lambda t} S^{-1}$ 瞬間可算。
2. **解耦微分方程組**：將高階 ODE 寫成狀態空間 $\dot{\mathbf{u}} = A\mathbf{u}$，解為 $\mathbf{u}(t) = e^{At}\mathbf{u}(0)$。
3. **奇異值分解（SVD）**：任意 $m \times n$ 矩陣都可寫作 $A = U\Sigma V^T$（不限方陣），其中奇異值 $\sigma_i = \sqrt{\lambda_i(A^TA)}$，廣泛用於最小平方法與資料降維。

## 考場易錯提醒
- 重複特徵值若幾何重數小於代數重數，矩陣**不可對角化**，此時需改用 Jordan Form。
- 實對稱矩陣（$A = A^T$）保證特徵值皆為實數，且不同特徵值的特徵向量必正交。
