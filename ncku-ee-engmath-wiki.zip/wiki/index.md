# 成大電機工程數學 LLM Wiki 總索引

> 本 Wiki 依據 `AGENTS.md` 規範建置，共 ingest **6 篇原始權威資料**，整理出 **7 篇結構化教學條目**，並與教學 HTML 簡報（`index.html`）一一對應。

## 一、原始資料清單（`raw/`）
| 編號 | 檔案 | 主題 | 來源 |
| :--- | :--- | :--- | :--- |
| R01 | `raw/01_ncku_ee_exam_scope.md` | 成大電機碩士班考科與工數範圍 | [成大圖書館考古題 EC15](https://exam.lib.ncku.edu.tw/master_subject.php?department_code=EC15)、[ColleGo!](https://collego.edu.tw/Highschool/MajorIntro?current_major_id=9&collegeFrom=2) |
| R02 | `raw/02_ode_first_second_order.md` | 一階與二階常微分方程 ODE | [Paul's Notes DE](https://tutorial.math.lamar.edu/classes/de/de.aspx)、[MIT OCW ES.1803](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/pages/class-notes/) |
| R03 | `raw/03_laplace_and_convolution.md` | 拉普拉斯轉換與摺積定理 | [Paul's Notes IVP](https://tutorial.math.lamar.edu/classes/de/ivpwithlaplace.aspx)、[Convolution](https://tutorial.math.lamar.edu/classes/de/convolutionintegrals.aspx) |
| R04 | `raw/04_fourier_series_and_transform.md` | 傅立葉級數與頻域疊加 | [MIT OCW 18.03SC](https://ocw.mit.edu/courses/18-03sc-differential-equations-fall-2011/pages/unit-iii-fourier-series-and-laplace-transform/fourier-series-basics/)、[ES.1803 Topic 21](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/mites_1803_s24_topic21.pdf) |
| R05 | `raw/05_linear_algebra_eigen_svd.md` | 特徵值、對角化與 SVD | [MIT OCW 18.06SC Diagonalization](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/least-squares-determinants-and-eigenvalues/diagonalization-and-powers-of-a/)、[SVD](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/positive-definite-matrices-and-applications/singular-value-decomposition/) |
| R06 | `raw/06_complex_residue_theorem.md` | 柯西積分公式與留數定理 | [MIT OCW 18.04 Topic 4](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/b1a90df19f643b974555bbbb93138a48_MIT18_04S18_topic4.pdf)、[Topic 8](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/3c58ce71ec6f7573804221d76158a0bd_MIT18_04S18_topic8.pdf) |

## 二、知識條目與簡報對應表（`wiki/` → `index.html`）
| Wiki 條目 | 核心主題 | 對應簡報頁碼 |
| :--- | :--- | :--- |
| [[overview]] (`wiki/overview.md`) | 為什麼電機工程離不開工程數學？五大單元全域地圖 | Slide 1–2, Slide 9 |
| [[ode]] (`wiki/ode.md`) | 常微分方程 ODE：描述動態變化率的語言 | Slide 3 |
| [[laplace]] (`wiki/laplace.md`) | 拉普拉斯轉換與摺積：把微積分變四則運算 | Slide 4 |
| [[fourier]] (`wiki/fourier.md`) | 傅立葉分析：拆解訊號的頻率配方 | Slide 5 |
| [[linear-algebra]] (`wiki/linear-algebra.md`) | 線性代數：特徵值、對角化與 SVD | Slide 6 |
| [[complex-analysis]] (`wiki/complex-analysis.md`) | 複變函數與留數定理：繞道複數平面解積分 | Slide 7 |
| [[control-bridge]] (`wiki/control-bridge.md`) | 跨科橋樑：沿用並銜接 `auto-control-wiki` | Slide 8, Slide 10 |
