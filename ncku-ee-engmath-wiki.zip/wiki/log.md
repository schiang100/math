# LLM Wiki 執行與檢查紀錄（Execution Log）

## 2026-11-23 — 建立流程（先討論、後生成）
- **[Node 1 — Topic & Schema]**：與使用者討論後定案主題為「成大電機碩士考試（工程數學）」，鎖定五大核心單元並規劃與既有 `auto-control-wiki` 的跨科橋樑；建立 `AGENTS.md` 與 `CLAUDE.md`。
- **[Node 2 — Source Ingest]**：完成 6 篇權威來源擷取並存入 `raw/01` 至 `raw/06`（超過作業要求之 5 篇下限），所有來源皆附可驗證之外部連結。
- **[Node 3 — Wiki Synthesis]**：依據 `raw/` 生成 7 篇概念條目（`overview`, `ode`, `laplace`, `fourier`, `linear-algebra`, `complex-analysis`, `control-bridge`）與 `wiki/index.md`，全面加入「一句話白話理解」與「生活／工程直覺」欄位。
- **[Node 4 — Wiki Integrity Gate]**：執行 `scripts/verify_wiki_and_slides.py` 進行結構與引用檢查（確認 raw >= 5、所有 `[[wikilink]]` 皆存在目標檔、每篇條目皆具外部來源 URL 與白話導讀欄位）。
- **[Node 5 — Slide Generation]**：讀取通過檢查的 `wiki/*.md` 生成教學型 HTML 簡報（`index.html`），包含 10 頁教學投影片、2 個互動式數學視覺化模擬器（s 域阻尼步階響應、傅立葉方波諧波合成）與內建 Wiki 檢視抽屜。
- **[Node 6 — Slide & Grounding Audit]**：透過自動檢查腳本驗證每一頁簡報皆對應到真實存在的 `wiki/*.md` 條目，並進行 HTML 語法、互動事件與無頭瀏覽器視覺排版檢查。
