# Raw 03：拉普拉斯轉換（Laplace Transform）與摺積定理（Convolution）

- **來源 1**：[Paul's Online Notes — Solving IVPs with Laplace Transforms](https://tutorial.math.lamar.edu/classes/de/ivpwithlaplace.aspx)
- **來源 2**：[Paul's Online Notes — Convolution Integrals](https://tutorial.math.lamar.edu/classes/de/convolutionintegrals.aspx)
- **來源 3**：[Paul's Online Notes — Table of Laplace Transforms](https://tutorial.math.lamar.edu/classes/de/laplace_table.aspx)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. **核心價值**：拉普拉斯轉換 $\mathcal{L}\{f(t)\} = F(s) = \int_0^{\infty} e^{-st} f(t)\,dt$ 能把時域中的微分方程初值問題（IVP）直接轉換為 $s$ 域中的「代數方程」，且初始條件 $y(0), y'(0)$ 會自動帶入計算，無須像傳統 ODE 先求通解再解聯立常數。
2. **微分的拉普拉斯性質**：
   - $\mathcal{L}\{y'(t)\} = sY(s) - y(0)$
   - $\mathcal{L}\{y''(t)\} = s^2Y(s) - s y(0) - y'(0)$
3. **三步解題流程**：(1) 兩邊取 Laplace 轉換 → (2) 用代數移項與部分分式展開解出 $Y(s)$ → (3) 查表取逆轉換 $\mathcal{L}^{-1}\{Y(s)\}$ 回到時域 $y(t)$。
4. **摺積定理（Convolution Integral）**：定義 $(f * g)(t) = \int_0^t f(t - \tau) g(\tau)\,d\tau$，其拉普拉斯轉換滿足 $\mathcal{L}\{f * g\} = F(s)G(s)$。當兩個 $s$ 域函數相乘、難以用部分分式拆解時，可直接透過摺積積分求逆轉換，也是電機系統「輸入與脈衝響應摺積得輸出」的數學基礎。
