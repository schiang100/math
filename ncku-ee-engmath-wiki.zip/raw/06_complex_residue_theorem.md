# Raw 06：複變函數 — 柯西積分公式與留數定理（Residue Theorem）

- **來源 1**：[MIT OCW 18.04 — Topic 4: Cauchy's Integral Formula](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/b1a90df19f643b974555bbbb93138a48_MIT18_04S18_topic4.pdf)
- **來源 2**：[MIT OCW 18.04 — Topic 8: Residue Theorem](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/3c58ce71ec6f7573804221d76158a0bd_MIT18_04S18_topic8.pdf)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. **柯西積分公式（Cauchy's Integral Formula）**：若 $f(z)$ 在簡單封閉曲線 $C$ 上及其內部皆解析（analytic），則對 $C$ 內部任一點 $z_0$，其函數值完全由邊界積分決定：
   $$f(z_0) = \frac{1}{2\pi i} \oint_C \frac{f(z)}{z - z_0}\,dz$$
   推廣至高階導數亦成立，把複數封閉路徑積分簡化為代值與微分。
2. **羅朗級數與留數（Residue）**：在孤立奇點 $z_0$ 附近展開為羅朗級數（Laurent Series）時，只有 $(z - z_0)^{-1}$ 項的係數 $b_1 = \operatorname{Res}(f, z_0)$ 對封閉積分有貢獻，其餘次方項積分皆為 0。
3. **留數定理（Cauchy's Residue Theorem）**：若 $f(z)$ 在簡單封閉路徑 $C$ 內僅有有限個孤立奇點 $z_1, \dots, z_k$，則：
   $$\oint_C f(z)\,dz = 2\pi i \sum_{j=1}^{k} \operatorname{Res}(f, z_j)$$
4. **考場核心應用**：透過在複數平面選取封閉半圓路徑（上半平面圍住奇點），能把實數軸上極難直接積分的瑕積分 $\int_{-\infty}^{\infty} f(x)\,dx$ 轉化為找極點、算留數的標準步驟。
