# Raw 05：線性代數核心 — 特徵值、對角化與奇異值分解（SVD）

- **來源 1**：[MIT OCW 18.06SC — Diagonalization and Powers of A](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/least-squares-determinants-and-eigenvalues/diagonalization-and-powers-of-a/)
- **來源 2**：[MIT OCW 18.06SC — Singular Value Decomposition (SVD)](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/positive-definite-matrices-and-applications/singular-value-decomposition/)
- **來源 3**：[MIT 18.06 Problem Set 9 — Matrix Exponential & ODE Systems](https://web.mit.edu/18.06/www/Spring09/pset9-s09-soln.pdf)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. **特徵值與特徵向量（Eigenvalues & Eigenvectors）**：滿足 $A\mathbf{x} = \lambda\mathbf{x}$ 的非零向量 $\mathbf{x}$，代表矩陣變換下「方向不變、只做伸縮」的主軸方向；由特徵多項式 $\det(A - \lambda I) = 0$ 求得特徵值 $\lambda$。
2. **矩陣對角化（Diagonalization）**：若 $n \times n$ 矩陣 $A$ 擁有 $n$ 個線性獨立的特徵向量，即可分解為 $A = S\Lambda S^{-1}$（$\Lambda$ 為特徵值組成的對角矩陣）。對角化能大幅簡化矩陣高次方 $A^k = S\Lambda^k S^{-1}$ 與矩陣指數 $e^{At} = S e^{\Lambda t} S^{-1}$ 的計算。
3. **與微分方程系統的連結**：高階 ODE 可改寫為一階狀態方程組 $\dot{\mathbf{u}} = A\mathbf{u}$，其解即為 $\mathbf{u}(t) = e^{At}\mathbf{u}(0)$；特徵值實部小於零代表系統隨時間收斂穩定。
4. **奇異值分解（SVD）**：對任意 $m \times n$ 矩形矩陣 $A$，皆可分解為 $A = U\Sigma V^T$，其中 $U, V$ 為正交矩陣（分別來自 $AA^T$ 與 $A^TA$ 的單位特徵向量），$\Sigma$ 為非負奇異值對角矩陣。SVD 不受限於方陣或可對角化條件，是資料降維、最小平方法與影像壓縮的基石。
