# Raw 02：一階與二階常微分方程（ODE）解題架構

- **來源 1**：[Paul's Online Notes — Differential Equations](https://tutorial.math.lamar.edu/classes/de/de.aspx)
- **來源 2**：[MIT OCW 18.03 — Differential Equations Class Notes](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/pages/class-notes/)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. **一階常微分方程（First-Order ODE）**：常見標準解法包括分離變數法（Separable）、一階線性積分因子法（Linear / Integrating Factor）、正合微分方程（Exact）與白努力方程（Bernoulli）。在工程中常用於建立一階動態模型（如 RC 電路充放電、阻力落體運動、混合槽模型）。
2. **二階線性常係數 ODE**：形式為 $a y'' + b y' + c y = g(t)$。
   - **齊性解（Homogeneous Solution, $y_h$）**：由特徵方程式 $a r^2 + b r + c = 0$ 的根決定，分為三種情況：相異實根（過阻尼）、重根（臨界阻尼，需乘上 $t$ 維持線性獨立）、共軛複根（欠阻尼，產生指數衰減乘上正弦/餘弦振盪）。
   - **特解（Particular Solution, $y_p$）**：對應外加輸入 $g(t)$ 的強迫響應，常用待定係數法（Undetermined Coefficients）或參數變換法（Variation of Parameters）。
3. **線性獨立與 Wronskian**：可用 Wronskian 行列式檢驗兩個齊性解是否線性獨立，構成完整通解 $y(t) = y_h(t) + y_p(t)$。
