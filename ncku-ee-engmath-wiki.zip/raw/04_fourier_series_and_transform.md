# Raw 04：傅立葉級數與頻域疊加分析（Fourier Series & Transform）

- **來源 1**：[MIT OCW 18.03SC — Fourier Series: Basics](https://ocw.mit.edu/courses/18-03sc-differential-equations-fall-2011/pages/unit-iii-fourier-series-and-laplace-transform/fourier-series-basics/)
- **來源 2**：[MIT OCW ES.1803 — Topic 21: Fourier Series Introduction](https://ocw.mit.edu/courses/es-1803-differential-equations-spring-2024/mites_1803_s24_topic21.pdf)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. **傅立葉級數核心思想**：任何滿足基本條件的週期函數 $f(t)$，都可以表示成一系列不同頻率正弦波（$\sin$）與餘弦波（$\cos$）的線性疊加：
   $$f(t) = \frac{a_0}{2} + \sum_{n=1}^{\infty} \left(a_n \cos(n\omega_0 t) + b_n \sin(n\omega_0 t)\right)$$
2. **為何電機工程需要傅立葉分析**：當線性定常系統 $P(D)x = f(t)$ 的輸入不是單純的正弦波，而是方波、三角波等週期訊號時，可先將輸入展開為傅立葉級數，利用「疊加原理（Superposition Principle）」分別計算每個頻率成分的響應，再加總還原。
3. **對稱性簡化技巧**：偶函數只需算 $a_n$（餘弦項），奇函數只需算 $b_n$（正弦項），能大幅節省考場計算時間。
4. **從級數到轉換**：當週期 $T \to \infty$（非週期訊號）時，離散頻譜變成連續頻譜，即為傅立葉轉換（Fourier Transform），用來分析訊號在各頻率上的能量分布。
