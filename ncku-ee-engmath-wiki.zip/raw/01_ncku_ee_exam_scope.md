# Raw 01：成大電機碩士班考古題架構與電機核心工程數學範圍

- **來源 1**：[國立成功大學圖書館碩士班考古題（電機工程學系 EC15）](https://exam.lib.ncku.edu.tw/master_subject.php?department_code=EC15)
- **來源 2**：[ColleGo! 電機工程學類核心課程介紹](https://collego.edu.tw/Highschool/MajorIntro?current_major_id=9&collegeFrom=2)
- **Ingest 日期**：2026-11-23

## 原始重點摘要
1. 根據國立成功大學圖書館碩士班考古題系統（電機工程學系代碼 EC15），自 75 學年度至 115 學年度歷屆入學考試中，「工程數學」持續並列為電機系碩士班的核心考科，與控制系統、電路學、線性代數、電磁學、電子學、電力工程等科目共同構成電機專業評量體系。
2. 根據 ColleGo! 電機工程學類課程說明，電機領域涵蓋電子、電力、資訊、通訊、控制、光電、晶片設計等方向；其必修核心「工程數學」主要包含五大工具：
   - **微分方程（Differential Equations）**
   - **拉普拉斯變換（Laplace Transform）**
   - **傅立葉變換（Fourier Transform / Series）**
   - **線性代數（Linear Algebra）**
   - **複變函數（Complex Variables）**（部分組別另含機率學）
3. 工程數學在電機系並非獨立純數學，而是電路學（暫態與 s 域分析）、訊號與系統（頻譜分析）、控制系統（轉移函數與穩定度）及通訊系統的共同語言。
