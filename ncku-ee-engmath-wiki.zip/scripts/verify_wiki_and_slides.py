#!/usr/bin/env python3
"""
LLM Wiki & HTML Slides 自動檢查腳本（Node 4 & Node 6 Validation Gate）
檢查項目：
1. raw/ 至少包含 5 篇原始資料
2. wiki/ 每篇概念條目皆包含：對應原始資料、外部來源 URL、一句話白話理解、生活／工程直覺
3. 所有 [[wikilink]] 皆能對應到真實存在的 wiki/<slug>.md
4. 若 index.html 已存在，檢查每頁投影片（data-wiki-ref）皆對應到真實存在的 wiki/*.md，且無壞連結
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "raw"
WIKI_DIR = ROOT / "wiki"
SLIDES_FILE = ROOT / "index.html"

errors = []
warnings = []

# Check 1: raw files >= 5
raw_files = sorted(RAW_DIR.glob("*.md"))
print(f"[Check 1] raw/ 原始資料數量: {len(raw_files)} 篇 (要求 >= 5)")
if len(raw_files) < 5:
    errors.append(f"raw/ 原始資料不足 5 篇，目前僅 {len(raw_files)} 篇")

# Check 2 & 3: wiki entries structure & wikilinks
wiki_files = sorted(p for p in WIKI_DIR.glob("*.md") if p.name not in ("index.md", "log.md"))
valid_slugs = {p.stem for p in wiki_files}
print(f"[Check 2] wiki/ 概念條目數量: {len(wiki_files)} 篇 ({', '.join(sorted(valid_slugs))})")

required_sections = ["對應原始資料", "外部來源", "一句話白話理解", "生活／工程直覺"]
url_pattern = re.compile(r"https?://[^\s\)\]]+")
link_pattern = re.compile(r"\[\[([a-zA-Z0-9_-]+)\]\]")

total_links = 0
for wf in wiki_files:
    text = wf.read_text(encoding="utf-8")
    for sec in required_sections:
        if sec not in text:
            errors.append(f"{wf.name} 缺少必要欄位: {sec}")
    if not url_pattern.search(text):
        errors.append(f"{wf.name} 缺少外部來源 URL")
    for m in link_pattern.finditer(text):
        total_links += 1
        target = m.group(1)
        if target not in valid_slugs:
            errors.append(f"{wf.name} 包含無效的 wikilink: [[{target}]]")

print(f"[Check 3] 交叉連結 [[wikilink]] 驗證完成: 共檢查 {total_links} 個連結")

# Check 4: slides <-> wiki mapping
if SLIDES_FILE.exists():
    html = SLIDES_FILE.read_text(encoding="utf-8")
    slide_refs = re.findall(r'data-wiki-ref="([^"]+)"', html)
    slide_count = len(re.findall(r'class="slide(?:\s|")', html))
    print(f"[Check 4] index.html 偵測到 {slide_count} 頁簡報，共 {len(slide_refs)} 個 Wiki 對應標籤")
    if slide_count == 0:
        errors.append("index.html 未偵測到任何 .slide 投影片元素")
    for ref in slide_refs:
        for item in [r.strip() for r in ref.split(",")]:
            if item == "index.md":
                continue
            target_path = WIKI_DIR / item
            if not target_path.exists():
                errors.append(f"index.html 引用了不存在的 Wiki 條目: wiki/{item}")
else:
    warnings.append("index.html 尚未生成（將於 Node 5 建立後再次驗證）")

print("-" * 50)
if warnings:
    for w in warnings:
        print(f"WARNING: {w}")
if errors:
    for e in errors:
        print(f"ERROR: {e}")
    print("RESULT: FAILED")
    sys.exit(1)
else:
    print("RESULT: PASSED (所有檢查項目皆通過)")
    sys.exit(0)
